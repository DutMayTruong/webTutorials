#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

void Input(unsigned int Array[], unsigned int* size);

void main(){
	unsigned int Array[10];
	unsigned int size = 0;
	unsigned int i;
	char str[20] = "1 2 3";
	//char *n;
	char sig[2] = " ";
	
	
	Input(Array,&size);

	//printf("%d\n",size);//debug

	for(i=0;i<size;i++){
		printf("%d\n",Array[i]);
	}
	
	

	getch();
}

void Input(unsigned int Array[], unsigned int* size){
	char str[256];
	unsigned int len;
	int inValid = 0;
	int spaceCount = 0;
	unsigned int i;
	int index;
	char* number;
	char* end;
	//int re,cur;
	unsigned long temp[10];

	do{
		inValid = 0;
		spaceCount = 0;
		//printf("1: %d\n",inValid);//debug

		// Clear string
		for(i=0;i<256;i++){
			str[i] = '\0';
		}

		// Read string from keyboard
		printf("Type series number, maximum of elements is 10:\n");
		fgets(str,sizeof(str),stdin);

		len = strlen(str);
		str[len-1] = '\0';
		len--;
		//printf("%s\n",str);//debug
		// Check string is valid or not
		if((len==0)||(len>109)){// Check input string 0 character or orver range
			inValid = 1;
		}
		//printf("2 %d\n",inValid);//debug

		if(!inValid){
			for(i=0;i<len;i++){
				if((str[i]<'0')||(str[i]>'9')){
					if(str[i]==' '){
						if((i==len-1)||(i==0)){
							inValid = 1;
							break;
						} else{
							if((str[i]==' ')&&(str[i+1]==' ')){
								inValid = 1;
								break;
							} else{
								spaceCount++;
							}
						}
					} else{
						inValid = 1;
						break;
					}
				}
			}
		}
		//printf("3 %d\n",inValid);//debug
		//printf("%d",spaceCount);//debug

		if(!inValid){
			if(spaceCount>9){
				inValid = 1;
			}
		}
		//printf("4 %d\n",inValid);//debug
		//printf("%s\n",str);//debug
		
		if(!inValid){
			index = 0;
			*size = spaceCount + 1;
			number = strtok(str," ");
			//printf("%s\n",number);//debug
			temp[index] = strtoul(number,&end,10);//debug
			//printf("%d\n",temp[index]);//debug
			Array[index] = temp[index];
			if(Array[index]==-1){
				inValid = 1;
			}
			index++;
			while((number = strtok(NULL," "))!=NULL){
				//printf("%s\n",number);//debug
				temp[index] = strtoul(number,&end,10);//debug
				//printf("%d\n",temp[index]);//debug
				Array[index] = temp[index];
				if(Array[index]==-1){
					inValid = 1;
				}
				index++;
			}
			
		}
		

		// Show message if input string is invalid
		if(inValid){
			printf("Input is invalid\n\n\n");
		}
	} while(inValid);
	
	//printf("%s",str);//debug
}